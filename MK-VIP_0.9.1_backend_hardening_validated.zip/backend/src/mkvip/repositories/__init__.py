"""Company persistence adapters."""
