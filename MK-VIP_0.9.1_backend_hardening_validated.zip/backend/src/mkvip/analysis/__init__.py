"""Fundamental analysis domain."""
